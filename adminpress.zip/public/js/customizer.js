// JavaScript Document
var reactUrl  = 'http://simplereactwordpress.com';
console.log('customizer.js');